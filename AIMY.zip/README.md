ChatBot Project - 'AIMY'
========================
using nodeJS
-------------

<img src="https://user-images.githubusercontent.com/37601696/86937758-977ddb00-c17a-11ea-88b0-f09bad347a97.png">
